
       /* var app = angular.module("myApp", []);
        app.controller("myCtrl", function($scope) {
            $scope.nomeAluno = "John";
            $scope.RA = "Doe";
        });*/
