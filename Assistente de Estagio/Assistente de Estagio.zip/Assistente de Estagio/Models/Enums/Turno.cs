﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assistente_de_Estagio.Models.Enums
{
    public enum Turno
    {
        Manha = 0,
        Tarde = 1,
        Noite = 2
    }
}
